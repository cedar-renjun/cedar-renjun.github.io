#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    value1 = 9;
    value2 = 499;
    mtimer1 = new QTimer;
    mtimer2 = new QTimer;

    mtimer1->setInterval(1000);
    mtimer2->setInterval(20);

    connect(mtimer1, SIGNAL(timeout()), this, SLOT(TickEclispe1()));
    connect(mtimer2, SIGNAL(timeout()), this, SLOT(TickEclispe2()));

}

Widget::~Widget()
{
    delete ui;
}

void Widget::TickEclispe1(void)
{
    if(value1)
    {
        QString tick;
        tick.sprintf("%d", value1--);
        ui->label->setText(tick);
    }
    else
    {
        mtimer1->stop();
        ui->label->setText("Stop");
    }
}

void Widget::TickEclispe2(void)
{
    if(value2)
    {
        QString tick;
        tick.sprintf("%d", value2);
        ui->label_2->setText(tick);
        value2 -= 1;
    }
    else
    {
        mtimer2->stop();
        ui->label_2->setText("Stop");
    }
}

void Widget::on_pushButton_clicked()
{
    ui->label->setText("9");
    ui->label_2->setText("499");
    value1 = 9;
    value2 = 499;
    mtimer1->start();
    mtimer2->start();
}
