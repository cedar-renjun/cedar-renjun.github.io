#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTimer>
#include <QDebug>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

public slots:
    void TickEclispe1(void);
    void TickEclispe2(void);

private slots:
    void on_pushButton_clicked();

private:
    Ui::Widget *ui;
    QTimer* mtimer1;
    QTimer* mtimer2;
    int value1;
    int value2;
};

#endif // WIDGET_H
