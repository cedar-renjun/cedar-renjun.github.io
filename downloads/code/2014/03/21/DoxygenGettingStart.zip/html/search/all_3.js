var searchData=
[
  ['simple_20device_20apis_20list_2e',['Simple device APIs list.',['../group___dev___a_p_i.html',1,'']]],
  ['simple_20device_20status_20information_2e',['Simple device status information.',['../group___dev___status.html',1,'']]]
];
