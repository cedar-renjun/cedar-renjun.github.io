var searchData=
[
  ['dev_5fclose',['Dev_Close',['../group___dev___a_p_i.html#ga31c94ebb29899ef7583a359b6ec6bbe9',1,'dev.h']]],
  ['dev_5fexample',['DEV_Example',['../main_8c.html#a1b381719fea84ae13a80d2b577c416ab',1,'main.c']]],
  ['dev_5finit',['Dev_Init',['../group___dev___a_p_i.html#ga52b3efdcf11fa94dcb0c226758df04b7',1,'dev.h']]],
  ['dev_5fprintint',['Dev_PrintInt',['../group___dev___a_p_i.html#ga1aebb1086a1105455317d2cba7f02d77',1,'dev.h']]],
  ['dev_5fstatuscheck',['Dev_StatusCheck',['../group___dev___a_p_i.html#ga18667ad3e4b3053e2b8f0166a5f982a8',1,'dev.h']]]
];
