var files =
[
    [ "dev.c", "dev_8c.html", null ],
    [ "dev.h", "dev_8h.html", "dev_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ]
];