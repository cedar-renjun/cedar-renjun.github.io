var group___dev___status =
[
    [ "DEV_OFF", "group___dev___status.html#ga2a7db2d5f48e0e31039d767df6b1aed9", null ],
    [ "DEV_ON", "group___dev___status.html#ga09d602af4524840941af687c7f903293", null ]
];