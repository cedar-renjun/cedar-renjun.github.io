var modules =
[
    [ "Simple device status information.", "group___dev___status.html", "group___dev___status" ],
    [ "Simple device APIs list.", "group___dev___a_p_i.html", "group___dev___a_p_i" ]
];