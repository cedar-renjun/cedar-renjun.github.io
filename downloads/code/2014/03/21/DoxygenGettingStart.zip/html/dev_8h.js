var dev_8h =
[
    [ "DEV_OFF", "dev_8h.html#ga2a7db2d5f48e0e31039d767df6b1aed9", null ],
    [ "DEV_ON", "dev_8h.html#ga09d602af4524840941af687c7f903293", null ],
    [ "Dev_Close", "dev_8h.html#ga31c94ebb29899ef7583a359b6ec6bbe9", null ],
    [ "Dev_Init", "dev_8h.html#ga52b3efdcf11fa94dcb0c226758df04b7", null ],
    [ "Dev_PrintInt", "dev_8h.html#ga1aebb1086a1105455317d2cba7f02d77", null ],
    [ "Dev_StatusCheck", "dev_8h.html#ga18667ad3e4b3053e2b8f0166a5f982a8", null ]
];