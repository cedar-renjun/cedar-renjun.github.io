var group___dev___a_p_i =
[
    [ "Dev_Close", "group___dev___a_p_i.html#ga31c94ebb29899ef7583a359b6ec6bbe9", null ],
    [ "Dev_Init", "group___dev___a_p_i.html#ga52b3efdcf11fa94dcb0c226758df04b7", null ],
    [ "Dev_PrintInt", "group___dev___a_p_i.html#ga1aebb1086a1105455317d2cba7f02d77", null ],
    [ "Dev_StatusCheck", "group___dev___a_p_i.html#ga18667ad3e4b3053e2b8f0166a5f982a8", null ]
];